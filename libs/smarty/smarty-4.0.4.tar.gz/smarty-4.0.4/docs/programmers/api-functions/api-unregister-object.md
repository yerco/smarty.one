unregisterObject()

dynamically unregister an object

Description
===========

void

unregisterObject

string

object\_name

See also [`registerObject()`](#api.register.object) and [objects
section](#advanced.features.objects)
